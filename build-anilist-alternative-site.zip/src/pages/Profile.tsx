import { useState } from 'react';
import { BookOpen, BarChart3, Users, Sparkles, Heart, ChevronDown, ChevronRight, Pin, MessageSquare, ThumbsUp, ThumbsDown } from 'lucide-react';
import { USER_PROFILE, ANIME_DB, POSTS, RANKS, getCoverGradient } from '../data/mockData';

const SIDE_SECTIONS = [
  { key: 'scroll', label: 'Scroll', icon: BookOpen },
  { key: 'stats', label: 'Stats', icon: BarChart3 },
  { key: 'social', label: 'Following / Followers', icon: Users },
  { key: 'additions', label: 'Additions', icon: Sparkles },
  { key: 'taste', label: 'Taste Twin %', icon: Heart },
];

export default function Profile() {
  const [openSections, setOpenSections] = useState<Record<string, boolean>>({
    scroll: true,
    stats: true,
    social: false,
    additions: false,
    taste: true,
  });

  const toggleSection = (key: string) => {
    setOpenSections(prev => ({ ...prev, [key]: !prev[key] }));
  };

  const completedCount = ANIME_DB.filter(a => a.status === 'completed').length;
  const watchingCount = ANIME_DB.filter(a => a.status === 'watching' || a.status === 'reading').length;
  const droppedCount = ANIME_DB.filter(a => a.status === 'dropped').length;
  const avgRating = ANIME_DB.filter(a => a.rating).reduce((sum, a) => sum + (a.rating || 0), 0) / ANIME_DB.filter(a => a.rating).length;
  const pinnedPosts = POSTS.filter(p => p.pinned);

  return (
    <div className="scroll-unroll flex flex-col lg:flex-row gap-6">
      {/* Left Sidebar */}
      <aside className="w-full lg:w-72 shrink-0 space-y-3">
        {/* Avatar Card */}
        <div className="paper-card rounded-xl p-5 text-center">
          <div className="mx-auto h-20 w-20 rounded-full bg-gradient-to-br from-vermillion to-vermillion-dark flex items-center justify-center text-white text-2xl font-bold font-serif-jp shadow-lg shadow-vermillion/20">
            SK
          </div>
          <h1 className="mt-3 text-lg font-bold text-ink font-serif-jp">{USER_PROFILE.username}</h1>
          <div className="mt-1 inline-flex items-center gap-1.5 rounded-full bg-vermillion/10 px-3 py-0.5">
            <span className="font-serif-jp text-sm text-vermillion">{USER_PROFILE.rank.kanji}</span>
            <span className="text-xs font-semibold text-vermillion">{USER_PROFILE.rank.name}</span>
          </div>
          {/* Starred emblems */}
          <div className="mt-3 flex justify-center gap-1.5">
            {USER_PROFILE.starred.map(entry => (
              <div
                key={entry.id}
                className={`group relative h-8 w-8 rounded-lg bg-gradient-to-br ${getCoverGradient(entry.id)} flex items-center justify-center text-white text-xs font-bold cursor-pointer transition-transform hover:scale-110`}
              >
                {entry.titleJp.charAt(0)}
                <div className="absolute -bottom-7 left-1/2 -translate-x-1/2 whitespace-nowrap rounded bg-ink px-2 py-0.5 text-[10px] text-white opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none z-20">
                  {entry.title}
                </div>
              </div>
            ))}
          </div>
          <p className="mt-1 text-[10px] text-ink-muted">Joined {USER_PROFILE.joinDate}</p>
        </div>

        {/* Collapsible Sections */}
        {SIDE_SECTIONS.map(section => {
          const Icon = section.icon;
          const isOpen = openSections[section.key];
          return (
            <div key={section.key} className="paper-card rounded-xl overflow-hidden">
              <button
                onClick={() => toggleSection(section.key)}
                className="flex w-full items-center gap-2 px-4 py-3 text-sm font-semibold text-ink hover:bg-ink/3 transition-colors"
              >
                <Icon size={15} className="text-vermillion" />
                <span className="flex-1 text-left">{section.label}</span>
                {isOpen ? <ChevronDown size={14} className="text-ink-muted" /> : <ChevronRight size={14} className="text-ink-muted" />}
              </button>
              {isOpen && (
                <div className="px-4 pb-3 text-sm">
                  <div className="brushstroke-divider mb-3" />
                  {section.key === 'scroll' && (
                    <div className="space-y-2">
                      <div className="flex justify-between"><span className="text-ink-muted">Total Entries</span><span className="font-semibold">{USER_PROFILE.scrollCount}</span></div>
                      <div className="flex justify-between"><span className="text-ink-muted">Completed</span><span className="font-semibold text-sage-green">{completedCount}</span></div>
                      <div className="flex justify-between"><span className="text-ink-muted">Watching / Reading</span><span className="font-semibold text-indigo-accent">{watchingCount}</span></div>
                      <div className="flex justify-between"><span className="text-ink-muted">Dropped</span><span className="font-semibold text-ink-muted">{droppedCount}</span></div>
                    </div>
                  )}
                  {section.key === 'stats' && (
                    <div className="space-y-2">
                      <div className="flex justify-between"><span className="text-ink-muted">Avg Rating</span><span className="font-semibold">{avgRating.toFixed(1)}</span></div>
                      <div className="flex justify-between"><span className="text-ink-muted">Anime</span><span className="font-semibold">{ANIME_DB.filter(a => a.type === 'anime').length}</span></div>
                      <div className="flex justify-between"><span className="text-ink-muted">Manga</span><span className="font-semibold">{ANIME_DB.filter(a => a.type === 'manga').length}</span></div>
                      <div className="flex justify-between"><span className="text-ink-muted">Top Genre</span><span className="font-semibold">Action</span></div>
                    </div>
                  )}
                  {section.key === 'social' && (
                    <div className="space-y-2 text-center">
                      <p className="text-ink-muted text-xs">Follow freely — no counts displayed publicly</p>
                      <button className="mt-1 rounded-lg bg-vermillion/10 px-4 py-1.5 text-xs font-semibold text-vermillion hover:bg-vermillion/20 transition-colors">
                        View Connections
                      </button>
                    </div>
                  )}
                  {section.key === 'additions' && (
                    <div className="space-y-2">
                      <div className="flex justify-between"><span className="text-ink-muted">Posts</span><span className="font-semibold">89</span></div>
                      <div className="flex justify-between"><span className="text-ink-muted">Echoes Written</span><span className="font-semibold">23</span></div>
                      <div className="flex justify-between"><span className="text-ink-muted">Recs Given</span><span className="font-semibold">15</span></div>
                    </div>
                  )}
                  {section.key === 'taste' && (
                    <div className="text-center">
                      <div className="text-3xl font-bold text-vermillion font-serif-jp">{USER_PROFILE.tasteTwin}%</div>
                      <p className="text-xs text-ink-muted mt-1">match with your taste</p>
                    </div>
                  )}
                </div>
              )}
            </div>
          );
        })}

        {/* Rank ladder */}
        <div className="paper-card rounded-xl p-4">
          <h3 className="text-xs font-semibold text-ink-muted uppercase tracking-wider mb-3">Rank Ladder</h3>
          <div className="space-y-1.5">
            {RANKS.map(rank => (
              <div
                key={rank.name}
                className={`flex items-center gap-2 rounded-lg px-2.5 py-1 text-xs ${
                  rank.name === USER_PROFILE.rank.name
                    ? 'bg-vermillion/10 text-vermillion font-bold'
                    : 'text-ink-muted'
                }`}
              >
                <span className="font-serif-jp text-sm w-5">{rank.kanji}</span>
                <span>{rank.name}</span>
                {rank.name === USER_PROFILE.rank.name && <span className="ml-auto text-[10px]">← You</span>}
              </div>
            ))}
          </div>
        </div>
      </aside>

      {/* Main Content */}
      <div className="flex-1 min-w-0 space-y-5">
        {/* Bio */}
        <div className="paper-card rounded-xl p-5 scroll-unroll scroll-unroll-delay-1">
          <h2 className="font-serif-jp text-lg font-semibold text-ink mb-2">About</h2>
          <div className="brushstroke-divider mb-3" />
          <p className="text-sm text-ink-light leading-relaxed">{USER_PROFILE.bio}</p>
        </div>

        {/* Pinned Posts */}
        {pinnedPosts.length > 0 && (
          <div className="space-y-3 scroll-unroll scroll-unroll-delay-2">
            <h2 className="font-serif-jp text-lg font-semibold text-ink flex items-center gap-2">
              <Pin size={16} className="text-vermillion" /> Featured Posts
            </h2>
            {pinnedPosts.map(post => (
              <div key={post.id} className="paper-card paper-card-hover rounded-xl p-4">
                <div className="flex items-start gap-3">
                  <div className="h-8 w-8 rounded-full bg-gradient-to-br from-vermillion to-vermillion-dark flex items-center justify-center text-white text-[10px] font-bold shrink-0">
                    {post.author.substring(0, 2).toUpperCase()}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="text-sm font-semibold text-ink">{post.author}</span>
                      <span className="text-[10px] font-serif-jp text-vermillion">{post.rank.kanji}</span>
                      <span className="text-[10px] text-ink-muted">• {post.timestamp}</span>
                      <span className="rounded-full bg-indigo-accent/10 px-2 py-0.5 text-[10px] font-medium text-indigo-accent">{post.channel}</span>
                      <span className="text-[10px] text-ink-muted">in {post.animeTitle}</span>
                    </div>
                    <p className="mt-1.5 text-sm text-ink-light leading-relaxed">{post.content}</p>
                    <div className="mt-2 flex items-center gap-4 text-xs text-ink-muted">
                      {post.agrees !== undefined && (
                        <>
                          <span className="flex items-center gap-1"><ThumbsUp size={12} /> {post.agrees}</span>
                          <span className="flex items-center gap-1"><ThumbsDown size={12} /> {post.disagrees}</span>
                        </>
                      )}
                      <span className="flex items-center gap-1"><MessageSquare size={12} /> {post.replies}</span>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}

        {/* Recent Activity */}
        <div className="space-y-3 scroll-unroll scroll-unroll-delay-3">
          <h2 className="font-serif-jp text-lg font-semibold text-ink">Recent Activity</h2>
          <div className="brushstroke-divider" />
          {POSTS.slice(0, 6).map(post => (
            <div key={post.id} className="paper-card paper-card-hover rounded-xl p-3.5">
              <div className="flex items-start gap-2.5">
                <div className={`h-7 w-7 rounded-full bg-gradient-to-br ${getCoverGradient(post.id)} flex items-center justify-center text-white text-[9px] font-bold shrink-0`}>
                  {post.author.substring(0, 2).toUpperCase()}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-1.5 flex-wrap">
                    <span className="text-xs font-semibold text-ink">{post.author}</span>
                    <span className="text-[9px] font-serif-jp text-vermillion">{post.rank.kanji}</span>
                    <span className="text-[9px] text-ink-muted">• {post.timestamp}</span>
                    <span className="rounded-full bg-indigo-accent/10 px-1.5 py-0.5 text-[9px] font-medium text-indigo-accent">{post.channel}</span>
                  </div>
                  <p className="mt-1 text-xs text-ink-light leading-relaxed line-clamp-2">{post.content}</p>
                  <div className="mt-1.5 flex items-center gap-3 text-[10px] text-ink-muted">
                    <span className="text-vermillion/70 font-medium">{post.animeTitle}</span>
                    {post.episode && <span>Ep. {post.episode}</span>}
                    <span className="flex items-center gap-0.5"><MessageSquare size={10} /> {post.replies}</span>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
