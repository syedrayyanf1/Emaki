import { useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { User, BookOpen, MessageSquare, Compass, Cherry, Gift, Menu, X } from 'lucide-react';
import { USER_PROFILE, getCoverGradient } from '../data/mockData';

const NAV_ITEMS = [
  { path: '/', label: 'Profile', icon: User },
  { path: '/scroll', label: 'Scroll', icon: BookOpen },
  { path: '/channels', label: 'Channels', icon: MessageSquare },
  { path: '/seasonal', label: 'Seasonal', icon: Cherry },
  { path: '/discover', label: 'Discover', icon: Compass },
  { path: '/extras', label: 'Extras', icon: Gift },
];

export default function Layout({ children }: { children: React.ReactNode }) {
  const location = useLocation();
  const [mobileOpen, setMobileOpen] = useState(false);

  return (
    <div className="min-h-screen bg-parchment">
      {/* Top Bar */}
      <header className="sticky top-0 z-50 border-b border-[#e8dfd2] bg-parchment/95 backdrop-blur-sm">
        <div className="mx-auto flex h-14 max-w-7xl items-center justify-between px-4">
          {/* Logo */}
          <Link to="/" className="flex items-center gap-2.5">
            <span className="text-2xl">🏮</span>
            <span className="font-serif-jp text-xl font-bold tracking-wide text-ink">
              Emaki
            </span>
            <span className="font-serif-jp text-xs text-ink-muted hidden sm:block">絵巻</span>
          </Link>

          {/* Desktop Nav */}
          <nav className="hidden md:flex items-center gap-1">
            {NAV_ITEMS.map(item => {
              const Icon = item.icon;
              const active = location.pathname === item.path;
              return (
                <Link
                  key={item.path}
                  to={item.path}
                  className={`flex items-center gap-1.5 rounded-lg px-3 py-1.5 text-sm font-medium transition-all ${
                    active
                      ? 'bg-vermillion/10 text-vermillion'
                      : 'text-ink-muted hover:text-ink hover:bg-ink/5'
                  }`}
                >
                  <Icon size={16} />
                  {item.label}
                </Link>
              );
            })}
          </nav>

          {/* Profile + Mobile Toggle */}
          <div className="flex items-center gap-3">
            {/* User mini */}
            <div className="flex items-center gap-2">
              <div className="h-8 w-8 rounded-full bg-gradient-to-br from-vermillion to-vermillion-dark flex items-center justify-center text-white text-xs font-bold">
                SK
              </div>
              <div className="hidden sm:flex flex-col">
                <span className="text-sm font-semibold text-ink leading-none">{USER_PROFILE.username}</span>
                <span className="text-[10px] text-vermillion font-medium">{USER_PROFILE.rank.kanji} {USER_PROFILE.rank.name}</span>
              </div>
              {/* Starred emblems */}
              <div className="hidden lg:flex items-center gap-1 ml-1">
                {USER_PROFILE.starred.slice(0, 4).map((entry) => (
                  <div
                    key={entry.id}
                    className={`group relative h-6 w-6 rounded-md bg-gradient-to-br ${getCoverGradient(entry.id)} flex items-center justify-center text-white text-[8px] font-bold cursor-pointer transition-transform hover:scale-110`}
                    title={entry.title}
                  >
                    {entry.titleJp.charAt(0)}
                    <div className="absolute -bottom-8 left-1/2 -translate-x-1/2 whitespace-nowrap rounded bg-ink px-2 py-0.5 text-[10px] text-white opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none z-50">
                      {entry.title}
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Mobile toggle */}
            <button
              onClick={() => setMobileOpen(!mobileOpen)}
              className="md:hidden p-1.5 rounded-lg text-ink-muted hover:text-ink hover:bg-ink/5"
            >
              {mobileOpen ? <X size={20} /> : <Menu size={20} />}
            </button>
          </div>
        </div>

        {/* Mobile Nav */}
        {mobileOpen && (
          <nav className="md:hidden border-t border-[#e8dfd2] bg-parchment px-4 py-2">
            {NAV_ITEMS.map(item => {
              const Icon = item.icon;
              const active = location.pathname === item.path;
              return (
                <Link
                  key={item.path}
                  to={item.path}
                  onClick={() => setMobileOpen(false)}
                  className={`flex items-center gap-2 rounded-lg px-3 py-2 text-sm font-medium transition-all ${
                    active
                      ? 'bg-vermillion/10 text-vermillion'
                      : 'text-ink-muted hover:text-ink hover:bg-ink/5'
                  }`}
                >
                  <Icon size={16} />
                  {item.label}
                </Link>
              );
            })}
          </nav>
        )}
      </header>

      {/* Main Content */}
      <main className="mx-auto max-w-7xl px-4 py-6">
        {children}
      </main>
    </div>
  );
}
